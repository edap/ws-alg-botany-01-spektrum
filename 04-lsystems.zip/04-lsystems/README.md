This example is done by Tom Brewe, it uses his library [lyndenmayer](https://github.com/nylki/lindenmayer).

In the console, run `node server.js`

Open in your browser this URL http://localhost:1337/index.html
